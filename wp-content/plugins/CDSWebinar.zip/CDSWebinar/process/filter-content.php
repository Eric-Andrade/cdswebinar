<?php

function r_filter_cdswebinar_content( $content ) {
    if (!is_singular('cdswebinar')) {
        return $content;
    }

    

    global $post;
    $cdswebinar_data            =   get_post_meta( $post->ID, 'cdswebinar_data', true );
    $cdswebinar_html            =   file_get_contents( 'cdswebinar-template.php', true );
    $cdswebinar_html            =   str_replace( "MESSAGEUSER_PH", $cdswebinar_data['messageuser'], $cdswebinar_html);
    $cdswebinar_html            =   str_replace( "PRIVACITY_PH", $cdswebinar_data['passwordsettings'], $cdswebinar_html);
    $cdswebinar_html            =   str_replace( "WEBINARLINK_PH", $cdswebinar_data['webinarlink'], $cdswebinar_html);
    $cdswebinar_html            =   str_replace( "COST_PH", '$200', $cdswebinar_html);
    $cdswebinar_html            =   str_replace( "IMG_PRESENTER", 'https://banner2.kisspng.com/20180517/uzq/kisspng-computer-icons-user-profile-male-avatar-5afd8d7b2682b3.7338522715265662671577.jpg', $cdswebinar_html);


    return $cdswebinar_html . $content;
}