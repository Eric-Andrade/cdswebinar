<?php
//! no workea :(
function r_get_cdswebinar_admin( $content ) {
     if (!is_singular('cdswebinar')) {
        return $content;
    }

    global $post;
    $cdswebinar_data            =   get_post_meta( $post->ID, 'cdswebinar_data', true );
    $cdswebinar_htmlx            =   file_get_contents( 'cdswebinar-template.php', true );
    $cdswebinar_htmlx            =   str_replace( "TEACHER_NAME_PH", 'Putin', $cdswebinar_htmlx);


    return $cdswebinar_htmlx . $content;
}