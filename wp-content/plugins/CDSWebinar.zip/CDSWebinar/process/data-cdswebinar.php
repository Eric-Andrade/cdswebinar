<?php

function r_data_cdswebinar() {
    print_r($_POST);
    die();
}